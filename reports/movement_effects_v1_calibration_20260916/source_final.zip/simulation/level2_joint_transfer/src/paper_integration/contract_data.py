"""实施合同：paper_coverage.csv + acceptance_contract.json 生成与哈希。

冻结于正式拟合与最终验证之前（任务书 §4）。哈希用于版本核对，
不构成执行真实性证明。ACCEPTANCE_PROTOCOL.md 在仓库中不存在，
已在合同 not_found 项登记；本合同按任务书 §3/§4/§8 规则执行。
"""
from __future__ import annotations

import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

CONTRACT_DIR = Path(__file__).resolve().parents[2] / "configs" / "paper_integration" / "contract"

# 每行：requirement_id, scope, paper, paper_location, target_observable,
# module, test_ids, run_command, key_param_sources, reference_anchor,
# match_criterion, failure_criterion, method
ROWS = [
    dict(requirement_id="B0", scope="core", paper="C(仓库现有)",
         paper_location="v10 报告 + run_20260915 归档",
         target_observable="Cs 基线回归：既有偏差仍被如实报告；初态束缚检查",
         module="paper_integration.runs (b0)",
         test_ids="test_b0",
         run_command="python -m paper_integration.cli run --stage preflight",
         key_param_sources="cs_existing(全部既有)",
         reference_anchor="v10：600μs 最大偏差 7.28pp（未通过 ±0.02）",
         match_criterion="初态束缚=0；历史偏差原样保留",
         failure_criterion="束缚检查失败或历史偏差被改写",
         method="既有引擎回归读取"),
    dict(requirement_id="M1", scope="core", paper="-",
         paper_location="-",
         target_observable="trial/atom 状态连续性、事件账本、键控随机流",
         module="paper_integration.events/dynamics3d",
         test_ids="test_m1_ledger,test_m1_rng",
         run_command="python -m paper_integration.cli run --stage preflight",
         key_param_sources="-",
         reference_anchor="不适用（基础设施）",
         match_criterion="删除死原子不改变他人噪声；真事件/检测分离",
         failure_criterion="随机流随数组重排改变",
         method="基础设施"),
    dict(requirement_id="R1", scope="core", paper="R=Bluvstein2022",
         paper_location="图1/ED2/Methods 等式(2)",
         target_observable="存活率与 ΔN vs 运输时长；解析 T^-4 标度",
         module="paper_integration.rb_transport",
         test_ids="test_r1",
         run_command="python -m paper_integration.cli run paper-rb2022 --stage scan",
         key_param_sources="rb87_2022_native(paper_measured 为主)",
         reference_anchor="110μm/300μs 高存活；Nmax∈[26,33]",
         match_criterion="C1 长T存活→1；C2 标度−4±0.6；C3 锚点存活>0.95",
         failure_criterion="任一结构判据失败",
         method="直接三维动力学"),
    dict(requirement_id="R2", scope="core", paper="R",
         paper_location="图1d",
         target_observable="Bell 运输保真度/ZZ/宇称振荡 vs 速度",
         module="paper_integration.rb_entangled",
         test_ids="test_r2",
         run_command="python -m paper_integration.cli run paper-rb2022 --stage scan",
         key_param_sources="c_phi=calibrated_on_training(110μm/300μs,94.8%)",
         reference_anchor="raw Bell 94.8(2)%；<0.55μm/μs 平台",
         match_criterion="C1 平台波动<2pp；C2 快速下降；C3 DD 开>关",
         failure_criterion="平台不存在或无快速下降",
         method="经典动力学+Pauli 轨迹"),
    dict(requirement_id="R3", scope="core", paper="R",
         paper_location="图3/ED 线路MC",
         target_observable="Steane |+̄⟩ raw/条件 ⟨X̄⟩/接受率",
         module="paper_integration.rb_circuit",
         test_ids="test_r3",
         run_command="python -m paper_integration.cli run paper-rb2022 --stage validation",
         key_param_sources="层误差 0.2/0.2/0.5/0.5%(paper_measured)；线路深度(assumed)",
         reference_anchor="0.71 / 0.991 / 66%",
         match_criterion="raw<0.9 且条件>raw 且接受率>0.4；差距如实报告",
         failure_criterion="结构关系颠倒",
         method="批量态矢量 MC"),
    dict(requirement_id="Y1", scope="core", paper="Y=Zhang2026",
         paper_location="ED Fig.2b/Methods §II",
         target_observable="存活率 vs 移动时长；zero/min-jerk；含/不含透镜",
         module="paper_integration.yb_transport",
         test_ids="test_y1",
         run_command="python -m paper_integration.cli run paper-yb2026 --stage scan",
         key_param_sources="yb171_2026_native；τ_eff=assumed(扫描{0,2,4,8})",
         reference_anchor="ED2b 曲线未数字化（Zenodo 未获取）→结构判据",
         match_criterion="C1 透镜限制快速运输；C2 含透镜 ZJ≥MJ；C3 无透镜近似",
         failure_criterion="任一判据在绝热窗口内失败",
         method="直接三维动力学+透镜"),
    dict(requirement_id="Y2", scope="core", paper="Y",
         paper_location="图1e/ED4/Methods §II.C",
         target_observable="三配置每单程失相干+翻转；Ramsey 对比度衰减",
         module="paper_integration.yb_vls",
         test_ids="test_y2",
         run_command="python -m paper_integration.cli run paper-yb2026 --stage validation",
         key_param_sources="κ=7mrad/nm(paper)；几何因子 optimal=paper_derived",
         reference_anchor="optimal<6e-4/单程；parallel 57Hz 强衰减",
         match_criterion="optimal≤1.5×上界；排序 static≤optimal≤parallel",
         failure_criterion="排序破坏或超界",
         method="半解析 MC"),
    dict(requirement_id="Y3", scope="core", paper="Y",
         paper_location="图2/ED3",
         target_observable="RT1 损失与擦除占比、RT5 占比、混淆矩阵",
         module="paper_integration.yb_leakage",
         test_ids="test_y3",
         run_command="python -m paper_integration.cli run paper-yb2026 --stage validation",
         key_param_sources="散射 0.3%/RT、r_e,l=0.72、FP/FN=1.4%(paper)；瞬态拆分(paper_derived)",
         reference_anchor="RT1 1.1(4)%、~50% 可擦除；RT5 ~10%",
         match_criterion="RT1 总量±0.5pp 内；占比 0.4-0.7；随 RT 下降",
         failure_criterion="占比不降或 RT1 超 2×论文值",
         method="泊松通道+能量阈值"),
    dict(requirement_id="Y4", scope="core", paper="Y",
         paper_location="图1c/ED6",
         target_observable="AR/TO 误差 vs ΔI/I 指数；误差构成",
         module="paper_integration.yb_gate",
         test_ids="test_y4",
         run_command="python -m paper_integration.cli run paper-yb2026 --stage validation",
         key_param_sources="ϵ0(paper)；指数 4/2(paper)；C_TO/C_AR(assumed)",
         reference_anchor="AR 擦除占比 38%；TO 丢失占比 75%",
         match_criterion="拟合指数 4±0.6/2±0.6；构成 ±5pp",
         failure_criterion="指数偏差>1",
         method="有效门通道 MC"),
    dict(requirement_id="Y5", scope="core", paper="Y",
         paper_location="图2/图3",
         target_observable="制备三口径；存储三口径解码",
         module="paper_integration.yb_code",
         test_ids="test_y5",
         run_command="python -m paper_integration.cli run paper-yb2026 --stage validation",
         key_param_sources="门误差/擦除/SPAM(paper)；线路深度(assumed 结构)",
         reference_anchor="制备 0.981/0.990/0.995；解码 0.874/0.902",
         match_criterion="三口径排序正确且量级(±5pp)——论文时间轴未公开则报告差距",
         failure_criterion="排序颠倒或偏差>10pp",
         method="批量态矢量 MC"),
    dict(requirement_id="Y6", scope="core", paper="Y",
         paper_location="图4",
         target_observable="逻辑传送成功：随机/自适应/后选；时延",
         module="paper_integration.yb_code.teleportation",
         test_ids="test_y6",
         run_command="python -m paper_integration.cli run paper-yb2026 --stage validation",
         key_param_sources="同 Y5+运输 0.55%/单程(paper_derived)",
         reference_anchor="0.771 / 0.802 / 0.87",
         match_criterion="自适应>随机(≥1pp) 且后选最高；差距如实报告",
         failure_criterion="自适应≤随机",
         method="批量态矢量 MC+反馈"),
    dict(requirement_id="I1", scope="core", paper="R+Y",
         paper_location="-",
         target_observable="τ_eff/运输速度扰动传播到逻辑观测量",
         module="paper_integration.integration",
         test_ids="test_i1",
         run_command="python -m paper_integration.cli run --stage integration",
         key_param_sources="耦合系数(assumed，登记)",
         reference_anchor="不适用（接通性检查）",
         match_criterion="扰动逐级传播（move→RT→逻辑 全部移动）",
         failure_criterion="任一环节不响应",
         method="链路重算"),
    dict(requirement_id="V1", scope="core", paper="全部",
         paper_location="-",
         target_observable="合同核对、复算入口、requirements_status",
         module="tools/verify_paper_integration.py",
         test_ids="-",
         run_command="python tools/verify_paper_integration.py --contract <dir> --run-dir <dir>",
         key_param_sources="-",
         reference_anchor="不适用（验收基础设施）",
         match_criterion="逐 ID 状态与证据路径完整",
         failure_criterion="缺证据或状态未登记",
         method="验收工具"),
]

SPLIT_POLICY = {
    "calibration": "R2 的 c_phi 在唯一锚点(110μm/300μs, 94.8%)上标定并冻结；"
                   "验证仅用形状判据（平台/下降/DD 对照），不再读取目标值。",
    "development": "模块冒烟与单元测试（tests/test_paper_integration_*.py）。",
    "final_holdout": "无独立实验曲线源数据（Zenodo/PDF 未获取）：Y1/R1/R2 的"
                     "绝对曲线不进入数值验收，仅结构判据；该限制已在各 ID 登记。",
}


def build_contract() -> dict:
    now = datetime.now(timezone.utc).isoformat()
    contract = {
        "version": "2026-09-15",
        "generated_utc": now,
        "scope_default": "core",
        "amendments": [
            {"id": "AMD-1", "requirement": "R1",
             "field": "C2 标度拟合窗口",
             "old": "0 < ΔN < 1e3（全部格点）",
             "new": "0.3 < ΔN_excess < 100（干净标度区）且网格加 250/400 μs",
             "reason": "原窗口把短 T 饱和区与长 T 热噪声底计入，T^-4 标度"
                           "不可测；目标斜率 −4±0.6 未变，判据未放宽",
             "impact": "R1 C2 由不可测变为可测"},
            {"id": "AMD-3", "requirement": "多处",
             "field": "口径/标签修正（独立验证 A 阶段发现 D1-D9）",
             "old": "Y6 后选含真实丢失；Y2 optimal 判据循环；Y4 指数称复现；"
                    "I1 称实际接通；B0 只读归档；sixth_zero_jerk 命名；"
                    "diag_expectation 乘积式；R2 解析读出",
             "new": "D3 后选只读检测+理想诊断单列；D4 循环性声明；D5 自洽声明；"
                    "D9 标量耦合声明+2σ；D8 本版初态实检；D2 重命名 low_peak_v；"
                    "D1 真实联合期望；D6 联合态参与读出；D7 入口语法修复",
             "reason": "独立验证（validation_plan.md A 阶段）证实六条线索与"
                       "一个入口语法缺陷；均为口径诚实性与缺陷修复，"
                       "未放宽任何通过阈值（AMD-1/2 的判据不变）",
             "impact": "Y6 postselected 数值口径改变；其余为标签/文档/回归修正"},
            {"id": "AMD-2", "requirement": "Y1",
             "field": "C2/C3 评估窗口",
             "old": "全部 T 格点",
             "new": "C2 仅部分损失区（透镜存活 0.02–0.98）；C3 仅绝热区"
                           "（无透镜存活 >0.98）",
             "reason": "全灭格点（两条轨迹存活均为 0）与快速非绝热格点上"
                           "判据无定义；阈值方向未变，未降低通过标准",
             "impact": "Y1 C2/C3 由交叉区噪声主导变为在定义域内评估"},
        ],
        "acceptance_protocol_file": {
            "path": "ACCEPTANCE_PROTOCOL.md",
            "status": "not_found_in_repository",
            "fallback": "按任务书 §3/§4/§8 执行，缺文件已如实登记"},
        "split_policy": SPLIT_POLICY,
        "frozen_commands": {
            "rb_scan": "python -m paper_integration.cli run paper-rb2022 --stage scan --shots 1024 --seed 20260915 --output-dir <out>",
            "yb_scan": "python -m paper_integration.cli run paper-yb2026 --stage scan --shots 1024 --seed 20260916 --output-dir <out>",
            "validation_rb": "python -m paper_integration.cli run paper-rb2022 --stage validation --trials 200000 --seed 20260917 --output-dir <out>",
            "validation_yb": "python -m paper_integration.cli run paper-yb2026 --stage validation --trials 200000 --seed 20260918 --output-dir <out>",
            "integration": "python -m paper_integration.cli run --stage integration --output-dir <out>",
            "verify": "python tools/verify_paper_integration.py --contract <contract-dir> --run-dir <run-dir>",
        },
        "numerical_tolerances": {
            "mc_precision": "存活率 Wilson95 半宽 ≤0.03（Y1/R1 正式 N≥1024）；"
                            "线路观测量 MC 误差 ≤0.004（N≥2×10⁵）",
            "step_check": "Y1/R1 步长 0.1/0.05 μs；smoke 与正式同参数仅增 N",
        },
        "requirements": ROWS,
    }
    return contract


def write_contract(out_dir: Path | None = None) -> dict:
    out = out_dir or CONTRACT_DIR
    out.mkdir(parents=True, exist_ok=True)
    contract = build_contract()
    payload = json.dumps(contract, ensure_ascii=False, sort_keys=True,
                         indent=1).encode()
    digest = hashlib.sha256(payload).hexdigest()
    contract["contract_sha256"] = digest
    (out / "acceptance_contract.json").write_text(
        json.dumps(contract, ensure_ascii=False, indent=1), encoding="utf-8")
    cols = ["requirement_id", "scope", "paper", "paper_location",
            "target_observable", "module", "test_ids", "run_command",
            "key_param_sources", "reference_anchor", "match_criterion",
            "failure_criterion", "method"]
    with open(out / "paper_coverage.csv", "w", newline="",
              encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in ROWS:
            w.writerow({c: r[c] for c in cols})
    return {"dir": str(out), "contract_sha256": digest,
            "n_requirements": len(ROWS)}


if __name__ == "__main__":
    print(write_contract())
